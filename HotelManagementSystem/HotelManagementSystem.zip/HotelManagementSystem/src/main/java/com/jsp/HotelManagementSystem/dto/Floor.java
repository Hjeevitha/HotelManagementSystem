package com.jsp.HotelManagementSystem.dto;

public enum Floor {

	GROUND,FIRST,SECOND;
}
